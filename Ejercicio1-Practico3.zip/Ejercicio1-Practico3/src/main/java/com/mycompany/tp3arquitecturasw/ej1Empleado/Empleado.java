
package com.mycompany.tp3arquitecturasw.ej1Empleado;

import lombok.Data;

@Data
public class Empleado {

    private String nombre;
    private String categoria;
    private String dedicacion;
    private Integer codigo;
}
