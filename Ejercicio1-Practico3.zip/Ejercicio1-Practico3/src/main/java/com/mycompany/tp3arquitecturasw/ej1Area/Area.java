
package com.mycompany.tp3arquitecturasw.ej1Area;

import lombok.Data;

@Data
public class Area {
    private Integer codigo;
    private String nombre;
    private String director;

}
