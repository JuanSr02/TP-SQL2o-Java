package com.mycompany.tp3arquitecturasw.objetos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;

@Data
@AllArgsConstructor
public class Nacion {

    @NonNull
    private String nombre;
    @NonNull
    private String bandera;
}
